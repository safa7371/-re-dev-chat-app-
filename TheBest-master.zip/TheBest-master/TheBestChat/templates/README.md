This is the main content for when a user logs in to the system and begins looking at their profile and tending to their chats, forums, and their posts.
The css also utilizes the fonts put in the previous directory.
