This is a directory in which the front end development team will push the work on the html/css pages for the website.
